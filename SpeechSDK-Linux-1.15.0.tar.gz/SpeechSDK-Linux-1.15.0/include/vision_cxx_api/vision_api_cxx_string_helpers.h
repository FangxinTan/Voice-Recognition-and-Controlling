//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <speechapi_cxx_string_helpers.h> // TODO: fully re-factor/duplicate/whatever <speechapi_cxx_string_helpers.h> to have vision sdk not rely directly on public headers from speech sdk
